from django.db import models


class Persona(models.Model):
    name = models.CharField(max_length=255, unique=True)
    instructions = models.TextField(help_text="Instructions for this persona")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ["name"]


class Conversation(models.Model):
    conversation_id = models.CharField(
        max_length=255, unique=True)  # Conversation ID
    bot_name = models.CharField(
        max_length=255, default="DefaultBot")  # Bot Name
    bot_config = models.TextField(null=True, blank=True)  # Bot Config
    participant_id = models.CharField(max_length=255)
    initial_utterance = models.CharField(max_length=255, null=True, blank=True)
    study_name = models.CharField(max_length=255, null=True, blank=True)
    user_group = models.CharField(max_length=255, null=True, blank=True)
    survey_id = models.CharField(
        max_length=255, null=True, blank=True)  # Survey ID
    survey_meta_data = models.TextField(
        null=True,
        blank=True,
    )  # Survey metadata (can be long)
    started_time = models.DateTimeField(auto_now_add=True)  # Start time

    # Track which persona was randomly selected for this conversation
    selected_persona = models.ForeignKey(
        Persona,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="conversations",
        help_text="The persona randomly selected for this conversation",
    )

    def __str__(self):
        return f"Conversation {self.conversation_id} started at {self.started_time}"


class Utterance(models.Model):
    conversation = models.ForeignKey(
        Conversation,
        on_delete=models.CASCADE,
        # Unique identifier per conversation
        related_name="utterances",
        null=True,
        blank=True,
    )
    speaker_id = models.CharField(max_length=255)  # 'participant' or 'bot'
    bot_name = models.CharField(max_length=255, null=True, blank=True)
    participant_id = models.CharField(max_length=255, null=True, blank=True)
    created_time = models.DateTimeField(auto_now_add=True)  # Timestamp
    text = models.TextField()

    # new fields added for voice chat
    audio_file = models.FileField(
        upload_to="utterance_audio/",
        null=True,
        blank=True,
    )  # path to saved audio
    # to distinguish voice vs text utterances
    is_voice = models.BooleanField(default=False)

    # Store the instruction prompt that was passed to the LLM for this utterance
    instruction_prompt = models.TextField(
        null=True,
        blank=True,
        help_text="The instruction prompt (bot prompt + persona) that was passed to the LLM for this utterance",
    )

    # Store the chat history that was passed to the LLM for this utterance
    chat_history_used = models.TextField(
        null=True,
        blank=True,
        help_text="The chat history (formatted as JSON) that was actually passed to the LLM for this utterance",
    )

    def __str__(self):
        return f"{self.speaker_id}: {self.text[:50]}"


class ModelProvider(models.Model):
    """Model provider (e.g., OpenAI, Anthropic)"""

    name = models.CharField(max_length=255, unique=True)
    display_name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.display_name

    class Meta:
        ordering = ["name"]

    @classmethod
    def get_or_create_default_providers(cls):
        """Create default providers if they don't exist"""
        providers_data = {
            "OpenAI": {
                "display_name": "OpenAI",
                "description": "OpenAI's language models including GPT series",
            },
            "Anthropic": {
                "display_name": "Anthropic",
                "description": "Anthropic's Claude language models",
            },
            "Bedrock": {
                "display_name": "Amazon Bedrock",
                "description": "Amazon Bedrock foundation models including Llama3",
            },
        }

        providers = {}
        for name, data in providers_data.items():
            provider, _ = cls.objects.get_or_create(
                name=name,
                defaults=data,
            )
            providers[name] = provider
        return providers


class Model(models.Model):
    """AI model with capabilities and provider relationship"""

    provider = models.ForeignKey(
        ModelProvider,
        on_delete=models.CASCADE,
        related_name="models",
    )
    model_id = models.CharField(
        max_length=255,
        help_text="The actual model ID used by the provider",
    )
    display_name = models.CharField(
        max_length=255, help_text="Human-readable name")
    description = models.TextField(blank=True)
    capabilities = models.JSONField(
        default=list,
        help_text="List of capabilities like ['Chat', 'Reasoning', 'Code']",
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.provider.display_name} - {self.display_name}"

    class Meta:
        unique_together = ["provider", "model_id"]
        ordering = ["provider__name", "display_name"]

    @classmethod
    def get_or_create_default_models(cls):
        """Create default models if they don't exist"""
        # First ensure providers exist
        providers = ModelProvider.get_or_create_default_providers()

        models_data = {
            "OpenAI": [
                {
                    "model_id": "gpt-5",
                    "display_name": "GPT-5",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "gpt-5-mini",
                    "display_name": "GPT-5 Mini",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "gpt-5-nano",
                    "display_name": "GPT-5 Nano",
                    "capabilities": ["Chat", "Basic Reasoning", "Code"],
                },
                {
                    "model_id": "gpt-4o",
                    "display_name": "GPT-4o",
                    "capabilities": ["Chat", "Vision", "Audio", "Reasoning"],
                },
                {
                    "model_id": "gpt-4o-mini",
                    "display_name": "GPT-4o Mini",
                    "capabilities": ["Chat", "Vision", "Audio", "Reasoning"],
                },
                {
                    "model_id": "gpt-4.1",
                    "display_name": "GPT-4.1",
                    "capabilities": ["Chat", "Reasoning", "Analysis"],
                },
                {
                    "model_id": "gpt-4.1-mini",
                    "display_name": "GPT-4.1 Mini",
                    "capabilities": ["Chat", "Reasoning", "Analysis"],
                },
                {
                    "model_id": "gpt-4.1-nano",
                    "display_name": "GPT-4.1 Nano",
                    "capabilities": ["Chat", "Basic Reasoning"],
                },
                {
                    "model_id": "gpt-4-turbo",
                    "display_name": "GPT-4 Turbo",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "gpt-4-turbo-preview",
                    "display_name": "GPT-4 Turbo Preview",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "gpt-3.5-turbo",
                    "display_name": "GPT-3.5 Turbo",
                    "capabilities": ["Chat", "Code", "Analysis"],
                },
            ],
            "Anthropic": [
                {
                    "model_id": "claude-opus-4-1-20250805",
                    "display_name": "Claude Opus 4.1",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "claude-opus-4-20250514",
                    "display_name": "Claude Opus 4",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "claude-sonnet-4-20250514",
                    "display_name": "Claude Sonnet 4",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "claude-3-5-haiku-20241022",
                    "display_name": "Claude 3.5 Haiku",
                    "capabilities": ["Chat", "Basic Reasoning", "Code"],
                },
                {
                    "model_id": "claude-3-7-sonnet-20250219",
                    "display_name": "Claude 3.7 Sonnet",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "claude-3-haiku-20240307",
                    "display_name": "Claude 3 Haiku",
                    "capabilities": ["Chat", "Basic Reasoning", "Code"],
                },
            ],
            "Bedrock": [
                {
                    "model_id": "meta.llama3-8b-instruct-v1:0",
                    "display_name": "Meta Llama 3 8B Instruct",
                    "capabilities": ["Chat", "Basic Reasoning", "Code"],
                },
                {
                    "model_id": "meta.llama3-70b-instruct-v1:0",
                    "display_name": "Meta Llama 3 70B Instruct",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "anthropic.claude-3-haiku-20240307-v1:0",
                    "display_name": "Anthropic Claude 3 Haiku",
                    "capabilities": ["Chat", "Basic Reasoning"],
                },
                {
                    "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
                    "display_name": "Anthropic Claude 3 Sonnet",
                    "capabilities": ["Chat", "Reasoning", "Code"],
                },
                {
                    "model_id": "anthropic.claude-3-5-sonnet-20240620-v1:0",
                    "display_name": "Anthropic Claude 3.5 Sonnet",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
                {
                    "model_id": "us.anthropic.claude-sonnet-4-20250514-v1:0",
                    "display_name": "Anthropic Claude Sonnet 4",
                    "capabilities": ["Chat", "Reasoning", "Code", "Analysis"],
                },
            ],
        }

        created_models = []
        for provider_name, models_list in models_data.items():
            provider = providers[provider_name]
            for model_data in models_list:
                model, created = cls.objects.get_or_create(
                    provider=provider,
                    model_id=model_data["model_id"],
                    defaults={
                        "display_name": model_data["display_name"],
                        "capabilities": model_data["capabilities"],
                    },
                )
                if created:
                    created_models.append(model)

        return created_models


class ModerationSettings(models.Model):
    enabled = models.BooleanField(
        default=True,
        help_text="When disabled, all content moderation is bypassed globally",
    )
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Global Moderation Setting"
        verbose_name_plural = "Global Moderation Settings"

    def save(self, *args, **kwargs):
        # Enforce singleton pattern
        if not self.pk and ModerationSettings.objects.exists():
            raise ValueError("Only one ModerationSettings record is allowed")
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Moderation {'Enabled' if self.enabled else 'Disabled'}"


class Bot(models.Model):
    # Make name the unique identifier
    name = models.CharField(max_length=255, unique=True,
                            default="DefaultBotName")
    prompt = models.TextField()  # Bot's prompt
    # Use foreign key to Model instead of separate model_type and model_id
    # Keep old fields for migration compatibility
    model_type = models.CharField(
        max_length=255,
        default="OpenAI",
        null=True,
        blank=True,
    )
    model_id = models.CharField(
        max_length=255,
        default="gpt-4o-mini",
        null=True,
        blank=True,
    )
    ai_model = models.ForeignKey(
        Model,
        on_delete=models.CASCADE,
        related_name="bots",
        null=False,
        blank=False,
    )
    initial_utterance = models.TextField(blank=True, null=True)

    # New Column:
    AVATAR_CHOICES = [
        ("none", "None"),
        ("default", "Default"),
        ("user", "User Provided"),
    ]
    avatar_type = models.CharField(
        max_length=20,
        choices=AVATAR_CHOICES,
        default="none",
    )

    # Avatar generation prompt
    avatar_prompt = models.TextField(
        blank=True,
        null=True,
        help_text="Prompt used for generating bot avatars. If empty, will use default prompt.",
    )

    # Message chunking control (bot-specific)
    chunk_messages = models.BooleanField(
        default=True,
        help_text="If true, split responses into human-like chunks; if false, send as one blob",
    )

    # Humanlike delay control (bot-specific)
    humanlike_delay = models.BooleanField(
        default=True,
        help_text="If true, apply human-like typing delays; if false, show messages instantly",
    )

    # NEW: Humanlike delay configuration (bot-specific) - all in seconds
    # Reading parameters
    reading_words_per_minute = models.FloatField(
        default=250.0,
        help_text="Words per minute reading speed for calculating reading delay",
    )
    reading_jitter_min = models.FloatField(
        default=0.1,
        help_text="Minimum reading jitter in seconds",
    )
    reading_jitter_max = models.FloatField(
        default=0.3,
        help_text="Maximum reading jitter in seconds",
    )
    reading_thinking_min = models.FloatField(
        default=0.2,
        help_text="Minimum reading thinking time in seconds",
    )
    reading_thinking_max = models.FloatField(
        default=0.5,
        help_text="Maximum reading thinking time in seconds",
    )

    # Writing parameters
    writing_words_per_minute = models.FloatField(
        default=200.0,
        help_text="Words per minute writing speed for calculating writing delay",
    )
    writing_jitter_min = models.FloatField(
        default=0.05,
        help_text="Minimum writing jitter in seconds",
    )
    writing_jitter_max = models.FloatField(
        default=0.15,
        help_text="Maximum writing jitter in seconds",
    )
    writing_thinking_min = models.FloatField(
        default=0.1,
        help_text="Minimum writing thinking time in seconds",
    )
    writing_thinking_max = models.FloatField(
        default=0.3,
        help_text="Maximum writing thinking time in seconds",
    )

    # Intra-message delays
    intra_message_delay_min = models.FloatField(
        default=0.1,
        help_text="Minimum delay between message parts in seconds",
    )
    intra_message_delay_max = models.FloatField(
        default=0.3,
        help_text="Maximum delay between message parts in seconds",
    )
    min_reading_delay = models.FloatField(
        default=1.0,
        help_text="Minimum reading delay in seconds",
    )

    # Follow-up on idle settings
    follow_up_on_idle = models.BooleanField(
        default=False,
        help_text="If true, bot will send follow-up messages when user is idle",
    )
    idle_time_minutes = models.IntegerField(
        default=2,
        help_text="Minutes of inactivity before considering user idle",
    )
    follow_up_instruction_prompt = models.TextField(
        blank=True,
        null=True,
        help_text="Instructions for generating follow-up messages when user is idle",
    )
    recurring_followup = models.BooleanField(
        default=False,
        help_text="If true, bot will keep sending follow-up messages while user is idle. If false, bot will only send one follow-up per idle period.",
    )

    # Transcript length control
    max_transcript_length = models.IntegerField(
        default=-1,
        help_text="Maximum number of messages to include in chat history. 0 = no chat history (only current message), 1+ = include that many most recent messages, negative = unlimited history.",
    )

    # Moderation settings - individual fields for each category
    moderation_harassment = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.50,
        help_text="Harassment threshold (0.0-1.0, lower = stricter)",
    )
    moderation_harassment_threatening = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.10,
        help_text="Harassment/threatening threshold (0.0-1.0, lower = stricter)",
    )
    moderation_hate = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.50,
        help_text="Hate threshold (0.0-1.0, lower = stricter)",
    )
    moderation_hate_threatening = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.10,
        help_text="Hate/threatening threshold (0.0-1.0, lower = stricter)",
    )
    moderation_self_harm = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.20,
        help_text="Self-harm threshold (0.0-1.0, lower = stricter)",
    )
    moderation_self_harm_instructions = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.50,
        help_text="Self-harm/instructions threshold (0.0-1.0, lower = stricter)",
    )
    moderation_self_harm_intent = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.70,
        help_text="Self-harm/intent threshold (0.0-1.0, lower = stricter)",
    )
    moderation_sexual = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.50,
        help_text="Sexual threshold (0.0-1.0, lower = stricter)",
    )
    moderation_sexual_minors = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.20,
        help_text="Sexual/minors threshold (0.0-1.0, lower = stricter)",
    )
    moderation_violence = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.70,
        help_text="Violence threshold (0.0-1.0, lower = stricter)",
    )
    moderation_violence_graphic = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=0.80,
        help_text="Violence/graphic threshold (0.0-1.0, lower = stricter)",
    )

    # Many-to-many relationship with personas
    personas = models.ManyToManyField(
        Persona,
        blank=True,
        related_name="bots",
        help_text="Select personas that this bot should embody",
    )

    def __str__(self):
        return self.name

    def get_moderation_threshold(self, category):
        """Get moderation threshold for a category."""
        field_mapping = {
            "harassment": self.moderation_harassment,
            "harassment/threatening": self.moderation_harassment_threatening,
            "hate": self.moderation_hate,
            "hate/threatening": self.moderation_hate_threatening,
            "self-harm": self.moderation_self_harm,
            "self-harm/instructions": self.moderation_self_harm_instructions,
            "self-harm/intent": self.moderation_self_harm_intent,
            "sexual": self.moderation_sexual,
            "sexual/minors": self.moderation_sexual_minors,
            "violence": self.moderation_violence,
            "violence/graphic": self.moderation_violence_graphic,
        }
        return float(field_mapping.get(category, 1.0))

    @classmethod
    def get_default_model(cls):
        """Get or create a default model for bots"""
        # Ensure default models exist
        Model.get_or_create_default_models()

        # Return the first available model (preferably GPT-4o Mini)
        try:
            return (
                Model.objects.filter(
                    provider__name="OpenAI",
                    model_id="gpt-4o-mini",
                ).first()
                or Model.objects.first()
            )
        except Exception:
            return None


class Keystroke(models.Model):
    # Respnose_ID but not FK to conversation because keystroke logging can happen without conversation registration
    conversation_id = models.CharField(max_length=255)
    total_time_on_page = models.FloatField()
    total_time_away_from_page = models.FloatField()
    keystroke_count = models.IntegerField()
    timestamp = models.DateTimeField(auto_now_add=False)

    def __str__(self):
        return (
            f"Keystroke log for conversation {self.conversation_id} at {self.timestamp}"
        )


class Avatar(models.Model):
    # New Column:
    CONDITION_CHOICES = [
        ("control", "control"),
        ("similar", "similar"),
        ("dissimilar", "dissimilar"),
    ]
    bot = models.ForeignKey(
        Bot,
        on_delete=models.CASCADE,
        related_name="avatars",
        null=True,
        blank=True,
    )
    bot_conversation = models.CharField(max_length=255, null=True, blank=True)
    condition = models.CharField(
        max_length=20,
        choices=CONDITION_CHOICES,
        default="similar",
    )
    participant_avatar = models.TextField(null=True, blank=True)
    chatbot_avatar = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Avatar for Conversation {self.bot.name} {self.bot.avatar_type} {self.condition} {self.participant_avatar} {self.chatbot_avatar}"
